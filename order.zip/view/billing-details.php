<div class="billing-detail-heading">Billing details</div>
<div class="row">
	<div class="form-label inline-block">
		Name <span class="required error"></span>

	</div>
	<div class="inline-block">
		<div id="first-name-info"></div>
		<input class="input-box-330" type="text" name="first-name"
			id="first-name">
	</div>
</div>
<div class="row">
	<div class="form-label">Address</div>
	<div class="inline-block">
		<input class="input-box-330" class="input-box-330" type="text"
			name="address">
	</div>
</div>
<div class="row">
	<div class="form-label">City</div>
	<div class="inline-block">
		<input class="input-box-330" type="text" name="city">
	</div>
</div>
<div class="row">
	<div class="form-label">Province</div>
	<div class="inline-block">
		<input class="input-box-330" type="text" name="state">
	</div>
</div>
<div class="row">
	<div class="form-label">Zipcode</div>
	<div class="inline-block">
		<input class="input-box-330" type="text" name="zipcode">
	</div>
</div>

<div class="row">
	<div class="form-label">
		Email Address<span class="required error"></span>
	</div>
	<div class="inline-block">
		<div id="email-info"></div>
		<input class="input-box-330" type="text" name="email" id="email">

	</div>
</div>
