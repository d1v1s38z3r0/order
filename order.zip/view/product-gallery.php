<div id="product-grid">
	<div class="txt-heading">Chosen products</div>
	<div class="product-item">
		<div class="product-image">
			<img src="data/camera.jpg" id="<?php echo "3DcAM01";?>"
				class="product-img">
		</div>
		<div>
			<strong><?php echo "Drum 200 Litre Plastic Drum";?></strong>
		</div>
		<div class="product-price"><?php echo "78.42";?></div>

		<input type="button" id="add_<?php echo "3DcAM01";?>"
			value="Add to cart" class="btnAddAction"
			onClick="cartAction('add', '<?php echo "3DcAM01";?>','<?php echo "Drum 200 Litre Plastic Drum";?>','<?php echo "78.42";?>')" />

	</div>
	
	
</div>